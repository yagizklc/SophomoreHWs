#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <queue>
using namespace std;

class Graph {

private:

	struct vertex {
		string word;
		string msg;
		vertex(string w, string m) {
			word = w;
			msg = m;
		}
		vertex(string w) {
			word = w;
		}
		vertex(){}
	};

	unordered_map<string, vector<vertex>> graph;
	vector<string> wordList;
	vector<char> letters;

public:

	// helper
	bool add_node(string u) {
		if (graph.find(u) != graph.end()) { // already in list
			return false;
		}
		vector<vertex> value;
		pair<string, vector<vertex>> keyvalue(u, value);
		graph.insert(keyvalue); // add new pair
		return true;
	}

	void reduceWord(string word, int& i) {
		string reducedWord, msg;
		reducedWord = word.substr(0, i) + word.substr(i+1); // reduced letter
		if (graph.find(reducedWord) != graph.end()) { // if reducedWord in wordList
			msg = "(delete " + string(1, word[i]) + " at position " + to_string(i+1)+ ")";
			graph[word].push_back(vertex(reducedWord, msg));
		}
	}
	void insWord(string word, int& i){
		string msg;
		for (int k = 0; k < letters.size(); k++) {
			string newWord = word.substr(0, i) + letters[k] + word.substr(i);
			string newWord2 = word + letters[k];
			if (graph.find(newWord) != graph.end()) {
				msg = "(insert " + string(1, letters[k]) + " after position " + to_string(i) + ")";
				graph[word].push_back(vertex(newWord, msg));
			}
			if (graph.find(newWord2) != graph.end()) {
				msg = "(insert " + string(1, letters[k]) + " after position " + to_string(word.length()) + ")";
				graph[word].push_back(vertex(newWord2, msg));
			}
		}
	}
	void transWord(string word, int& i) {
		char c;
		string msg;
		for (int k = 0; k < letters.size(); k++) { // try every letter substitution
			string newWord = word;	// copy word
			c = letters[k]; // ascii int to char
			if (c != word[i]) { // if not same letter 
				newWord[i] = c; // newWord by substitution
				if (graph.find(newWord) != graph.end()) {  //  if newWord in wordList
					msg = "(change " + string(1, word[i]) + " at position " + to_string(i+1) + " to " + string(1, c) + ")";
					graph[word].push_back(vertex(newWord, msg));
				}
			}
		}
	}
	void isEdge(string& word) {
		for (int i = 0; i < word.length(); i++) { // for all letters in word
			insWord(word, i); // edge by 1 letter insertion
			reduceWord(word, i); // edge by 1 letter deduction
			transWord(word, i); // edge by 1 letter transformation
		}
	}

	// accessor
	unordered_map<string, vector<vertex>>* getGraph() { return &graph; }

	
	// constructor
	Graph() {};
	Graph(vector<string>& wordListC, vector<char> &lettersC) : wordList(wordListC), letters(lettersC){
		for (int i = 0; i < wordList.size(); i++) { // add all vertexes to graph
			add_node(wordList[i]);
		}
		for (int k = 0; k < wordList.size(); k++) {
			isEdge(wordList[k]);
		}
	}
	
	// member
	void bfs(string start, string end) {
		queue<vertex> queue;
		unordered_map<string, bool> visited(false);
		unordered_map<string, vertex> paths;

		queue.push(vertex(start));

		vertex v, w;
		while (!queue.empty()) {  // while queue not empty or not found end
			v = queue.front(); // pop 
			queue.pop();
			visited[v.word] = true;

			for (int i = 0; i < graph[v.word].size(); i++) { // every adj w of v
				w = graph[v.word][i];
				if (visited[w.word] == false) { // if w wasnt visited
					visited[w.word] = true;
					paths[w.word] = v; // path 
					if (w.word == end) {
						print_graph(w, paths);
						return;
					}
					queue.push(w); // add to queue
				}
			}
		}
	}
	void print_graph(vertex v, unordered_map<string, vertex>& paths) {
		if (paths.find(v.word) == paths.end()) { // last node
			cout << v.word << endl;
		}
		else {
			print_graph(paths[v.word], paths);
			cout << v.word << " " << v.msg << endl;
		}
	}
};


int main() {


	// reading from txt
	vector<string> wordList;
	ifstream input("words.txt");
	string word;
	while (input >> word) {
		wordList.push_back(word);
	}


	// letters init
	vector <char> letters;
	char c;
	for (int i = 65; i < 91; i++) {
		c = i;
		letters.push_back(c);
	}
	for (int i = 97; i < 122; i++) {
		c = i;
		letters.push_back(c);
	}
	letters.push_back(39);


	// init graph
	Graph graph(wordList, letters);


	// read two words from list
	string w1, w2;

	cout << "Please enter two words: "; // ADDED but not imp
	while (cin >> w1 >> w2) {
		if (w1[0] == '*') { return 0; } // if starts with * or at least one of them is not in list
		else if (graph.getGraph()->find(w1) == graph.getGraph()->end() || graph.getGraph()->find(w2) == graph.getGraph()->end()) { // return error
			cout << "Word(s) is/are not in the list!" << endl; // Changed but not imp
			// return 0; this part is removed
		}
		else { // if valid input -> find shortest path via breadth-first search
			graph.bfs(w1, w2);
			cout << endl;
		}
		cout << "Please enter two words: ";
	}

	return 0;
}